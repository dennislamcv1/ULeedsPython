import os
import sys
from src.a_star import AStar
from src.text_environments import text_environments

def red(text):
    return f'\033[31m{text}\033[0m'

def green(text):
    return f'\033[32m{text}\033[0m'

def blue(text):
    return f'\033[34m{text}\033[0m'

def black(text):
    return f'\033[97m\033[40m{text}\033[0m'

def clear_console():
    os_name = os.name
    if os_name == "nt":  # Windows
        os.system("cls")
    elif os_name == "posix":  # macOS and Linux
        os.system("clear")

def path_finding(robot):
    a_star = AStar(robot)
    path = None

    while a_star.search_ongoing():
        current = a_star.get_current_node()
        if current == robot.goal_cell:
            path = a_star.get_path(current)
            break

        for neighbour in robot.get_neighbours(current):
            tentative_score = a_star.get_tentative_score(current)
            if tentative_score < a_star.get_neighbour_score(neighbour):
                a_star.update_neighbour_score(current, neighbour, tentative_score)
                if a_star.neighbour_not_in_queue(neighbour):
                    a_star.add_neighbout_in_queue(neighbour)
    return path

def check_input():
    if len(sys.argv) < 2:
        print('You need to specify the environment: python main_basic.py env1')
        sys.exit(1)
    elif not valid_environment_name(sys.argv[1]):
        print(f'You need to specify a valid environment name. Valid names are: {", ".join(get_valid_env_names())}')
        sys.exit(1)

def get_valid_env_names():
    return text_environments.keys()

def valid_environment_name(environment_name):
    return environment_name in text_environments

def get_environment(environment_name):
    return text_environments[environment_name]

