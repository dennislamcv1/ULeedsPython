from enum import Enum

class Direction(Enum):
    Up=1
    Down=2
    Left=3
    Right=4

