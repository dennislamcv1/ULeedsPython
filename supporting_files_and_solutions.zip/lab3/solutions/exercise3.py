number_1 = float(input('Please provide the first number: '))
number_2 = float(input('Please provide the second number: '))

print(f'Addition: {number_1 + number_2}')
print(f'Subtraction: {number_1 - number_2}')
print(f'Multiplication: {number_1 * number_2}')
print(f'Division: {number_1 / number_2}')
