import random

def get_random_secret():
    return random.randint(0, 100)

# TODO: define the required parameter (i.e., the guess) 
# in the is_guess_valid function below
def is_guess_valid():
    #TODO: add a return line to return True if the guess 
    # is valid or False if not (you need to use the 
    # AND operator: the number is great or equal (>=) to 
    # 0 AND less or equal (<=) to 100).

# TODO: define the required parameters (you need the 
# "guess" and the "secret") in the "how_off_is_the_guess"
# function below.
def how_off_is_the_guess():
    # diff will hold the absolute difference between the two
    # (i.e., not signed, so for 10-30 you will get 
    # 20 [instead of -20] and for 30-10 you will also 
    # get 20)
    diff = abs(guess - secret)

    # TODO: use the diff and if/elif/else to print something 
    # about the distance from secret (hot, very hot, cold, 
    # very cold etc). For example, if diff >= 10 print "cold",
    # else if diff >= 20 print "very cold", else if diff <= 5 
    # print "hot", else if diff <= 3 print "very hot" (or any
    # other logic you would like).


secret = # TODO: call the "get_random_secret" function here to get the secret number.
counter = 1

while True:
    # TODO: read number from user below and store it in the "guess" variable, don't 
    # forget to convert it to integer.
    guess =

    # TODO: check with an if here below if the guess provided is 
    # valid (use the function you wrote is_guess_valid passing the guess 
    # as an argument).
    if : 
        # TODO: since guess is valid, now check if the guess was the secret 
        # (remember the == comparisong operator). Complete the if statement 
        # below.
        if :
            # TODO: replace ___ with the appropriate variables (using {my_var}).
            print(f'Congrats! The secret was __. You found the secret after __ attempts.')

            # TODO: since the user found the secret, we need to stop the loop; what command 
            # did you learn to stop a loop (i.e., to BREAK out of a loop)?
        else:
            # TODO: the guess is not the secret, call your "how_off_is_the_guess" 
            # function to print out how off the user was.

        # Since a valid guess was provided, we increment the 
        # counter by 1.
        counter = counter + 1
    else: 
        # TODO: if the guess is not valid, just let the user know with a 
        # nice message that the input isn't valid and instruct what a valid 
        # input looks like (i.e., a number from 0 to 100). Use f-string
        # to inject dynamic values (like the secret number and the counter 
        # value).
