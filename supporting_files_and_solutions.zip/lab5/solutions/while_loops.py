secret = 7
counter = 0

while True:
    guess = int(input('Provide your guess: '))
    counter += 1

    if guess == secret:
        print(f'Congrats! The secret number is {secret}. You found the secret after {counter} attempts.')
        break
    else:
        print('Wrong input. Try again.')

