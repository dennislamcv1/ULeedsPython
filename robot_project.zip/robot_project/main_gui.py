import sys
from src.direction import Direction
from src import utils
from src.gui_environments import gui_environments
    

# TODO: define a function here.


utils.check_input()
robot = gui_environments[sys.argv[1]]
path = utils.path_finding(robot)

if path: # This checks if there was a path
    # TODO: call the function here to move the robot on the path.

while True:
    robot.draw()

