total = 0

# TODO: complete the for loop, how would you make it to iterate 10 times?
for i in ...
    # TODO: read the input from the user and store it in the variable mark; 
    # remember to convert it to integer.
    mark = 

    # Here we simply update the total to include the new mark. 
    # We assume the input will always be valid.
    total = total + mark

    if mark >= 8 and mark <= 10:
        print(f'Student {i} grade: A')
    elif ...: # Complete the second elif.
        # TODO: What would you print here?
    elif ...: # Complete the second elif.
        # TODO: What would you print here?
    elif ...: # Complete the second elif.
        # TODO: What would you print here?

mean = # TODO: now compute the mean here!

# TODO: the f-string needs updating; replace ___ with 
# the appropriate variable.
print(f'The mean of the class is ___')
