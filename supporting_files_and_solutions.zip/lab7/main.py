import sys
from src import utils
from src.direction import Direction


# TODO: Define a function named "solve" below with a single
# parameter named "robot". Remember use the "def" keyword 
# to define a function followed by the function name (solve), 
# and in parenthesis () define the parameter (robot).
# Replace ____ below with the actual function definition.
def ____ :

    # TODO: Below add the lines required to move the robot
    # from start to goal. Again, have a look at the board 
    # configuration from the instructions and figure out the
    # move directions needed. We provide the first move
    # action for you (move the robot right). Don't forget
    # that if the robot needs to execute the same motion 
    # more than once sequentially, to put those motions 
    # in a for loop instead of writing the same command 
    # multiple times.

    robot.move(Direction.Right)

    # add more move actions to solve the problem here.

    # TODO: Implement the if statement to check if the
    # robot reached the goal. Remember, you can access
    # the current position of hte robot using 
    # robot.position and you can also access the goal cell
    # using robot.goal_cell
    # Hint: you can compare the two using ==
    # Replace the ____ below to implement the if statement.
    if ____:
        # TODO: Add a line below to print a success message to user.

        # TODO: Complete the print statement below to print the number
        # of steps the robot took. Remember, you can use "robot.num_motions"
        # to get the number of motions the robot executed.
        print(f'Number of steps: ...')
    else:
        # TODO: what would you print here, if the if condition was False?
        # If the if condition is True it means success, what would the 
        # False mean?


utils.check_input()
robot = utils.get_environment(sys.argv[1])
robot.print_board()
    
# TODO: call your "solve" function here and don't forget 
# to pass as an argument the "robot".
