my_name = 'Your Name Here'
age = 21

print(f'Hello, my name is {my_name} and I am {age} years old.')
