import time
import sys
from collections import defaultdict
from src import utils
from src.cell import Cell
from src.direction import Direction


class Robot:
    def __init__(self, board_size, obstacles, start_cell, goal_cell):
        self.board_size = board_size
        self.obstacles = obstacles
        self.num_motions = 0
        self.set_start_position_of_robot(start_cell)
        self.set_goal_position(goal_cell)

    def is_cell_valid(self, cell):
        return cell.row >= 1 and cell.row <= self.board_size \
               and cell.column >= 1 and cell.column <= self.board_size

    def is_cell_free(self, cell):
        return cell not in self.obstacles

    @property
    def position(self):
        return self.__robot_position

    def set_start_position_of_robot(self, cell: Cell):
        cell_valid_and_free = self.is_cell_valid(cell) and self.is_cell_free(cell)
        if not cell_valid_and_free:
            print('The provided cell is invalid: is either out of range or the cell contains an obstacle ("X").')
            sys.exit(1)
        self.__robot_position = cell

    def set_goal_position(self, cell: Cell):
        cell_valid_and_free = self.is_cell_valid(cell) and self.is_cell_free(cell)
        if not cell_valid_and_free:
            print('The provided cell is invalid: is either out of range or the cell contains an obstacle ("X").')
            sys.exit(1)
        self.goal_cell = cell

    def print_board(self):
        utils.clear_console()
        print('   ', end='')
        for x in range(self.board_size):
            print(f'{utils.black(x+1)}  '.center(3), end="")
        print()

        square = utils.black("\u25A1")
        for row in range(1, self.board_size + 1):
            print(str(row).rjust(2) + " ", end="")
            for col in range(1, self.board_size + 1):
                if Cell(row, col) in self.obstacles:
                    print(f'{utils.red("X")}  '.center(3), end="")
                elif Cell(row, col) == self.position:
                    print(f'{utils.blue("R")}  '.center(3), end="")
                elif Cell(row, col) == self.goal_cell:
                    print(f'{utils.green("G")}  '.center(3), end="")
                else:
                    print(f'{square}  '.center(3), end="")
            print()
        print()

    def move(self, direction: Direction):
        current_row = self.position.row
        current_col = self.position.column

        next_cell = self.position
        if direction == Direction.Up:
            next_cell = Cell(current_row - 1, current_col)
        elif direction == Direction.Down:
            next_cell = Cell(current_row + 1, current_col)
        elif direction == Direction.Left:
            next_cell = Cell(current_row, current_col - 1)
        elif direction == Direction.Right:
            next_cell = Cell(current_row, current_col + 1)

        next_cell_valid_and_free = self.is_cell_valid(next_cell) and self.is_cell_free(next_cell)
        if not next_cell_valid_and_free:
            print(f'The motion you attempt to execute (going {direction.name.lower()}) from the robot\'s current position {self.position} is going to be invalid.')
            if not self.is_cell_valid(next_cell):
                print('The robot will go outside the board.')
            elif not self.is_cell_free(next_cell):
                print('The robot will bump into an obstacle.')
            sys.exit(1)

        self.__robot_position = next_cell
        self.num_motions += 1
        self.print_board()
        time.sleep(0.5)

    @property
    def graph(self):
        # Create an empty graph
        graph = defaultdict(list)

        # Iterate over all free cells and add edges between neighboring free cells
        for row in range(1, self.board_size + 1):
            for col in range(1, self.board_size + 1):
                cell = Cell(row, col)
                if self.is_cell_free(cell) and self.is_cell_valid(cell):
                    actions = [ 
                        (Cell(row - 1, col), Direction.Up),
                        (Cell(row + 1, col), Direction.Down),
                        (Cell(row, col - 1), Direction.Left),
                        (Cell(row, col + 1), Direction.Right),
                    ]
                    
                    for next_cell, direction in actions:
                        if self.is_cell_free(next_cell) and self.is_cell_valid(next_cell):
                            graph[cell].append(direction)

        return graph

    def get_next_cell_from_a_cell_moving_to_a_direction(self, cell, direction):
        if direction == Direction.Up:
            return Cell(cell.row - 1, cell.column)
        elif direction == Direction.Down:
            return Cell(cell.row + 1, cell.column)
        elif direction == Direction.Left:
            return Cell(cell.row, cell.column - 1)
        elif direction == Direction.Right:
            return Cell(cell.row, cell.column + 1)

    def get_neighbours(self, cell):
        neighbours = []
        graph = self.graph
        actions = graph[cell]

        for action in actions:
            neighbours.append(self.get_next_cell_from_a_cell_moving_to_a_direction(cell, action))

        return neighbours

