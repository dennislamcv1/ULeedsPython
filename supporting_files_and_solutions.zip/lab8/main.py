import sys
from src.direction import Direction
from src import utils


# TODO: define a function named "move_robot_on_path" below
# with two parameters, "robot" and "path". Order of the parameters
# is important, so define as first parameter the "robot" then
# the "path". Replace "____" with the actual function definition.
def ____:
    # Let's iterate over the cells in the path using a for loop.
    for next_cell in path:
        
        # TODO: we want the current cell to keep the current position
        # of the robot. We can access the position of the robot using
        # robot.position
        current_cell = ____


        # TODO: Implement the if statement below such that it will cause
        # the robot to move to the right direction dictated by the path. 
        # The for loop iterates over the path and gives us a "next_cell" 
        # each time until the robot reaches the goal.
        # This is the next cell the robot needs to move to.
 
        # The robot is currently at "current_cell". We
        # want the robot to move to the "next_cell". Remember that the
        # "current_cell" and the "next_cell" both have a ".row" and 
        # ".column" attribute. So you can access the row like so: 
        # current_cell.row and the column like so: current_cell.column
        # (the same applies for next_cell).

        # For each possible direction (Up, Down, Left, Right), implement
        # the if statement such that the robot will move to the right 
        # direction.
        
        # Hint (example): if  current_cell.row = 1  and  current_cell.column = 4 
        # it means the robot is at row 1 and column 4. 
        #
        # If the next_cell.row = 1 and next_cell.column = 5 
        # (that is, the next cell in the path tell us the robot should move to 
        # cell at row 1 and column 5), then what does that means in terms 
        # of the motion the robot needs to execute? 
        #
        # Well it tells us that the robot is at the same row (row 1) and only 
        # moved a column. This tells us something in terms of the motion.
        #
        # The robot did not move a row which means that it did not move 
        # Up or Down (motion in row moves the robot either up or down).
        #
        # So our only options are: the robot moved either left or right (because
        # there is a change in column only).
        #
        # If the change is positive, the robot moved right and if negative left.
        # In this example, the robot moved RIGHT! Let's use this intution to 
        # implement the if statement:   
        #    if current_cell.row == next_cell.row and current_cell.column + 1 == next_cell.column:
        #       robot.move(Direction.Right)

        # Replace all ___ with the right code and move the robot to 
        # the right direction.
        if ____:
            robot.move(____)
        elif ____:
            robot.move(____)
        elif ____:
            robot.move(____)
        elif ____:
            robot.move(____)


    # TODO: Implement the if statement to check if the
    # robot reached the goal. Remember, you can access
    # the current position of hte robot using 
    # robot.position and you can also access the goal cell
    # using robot.goal_cell
    # Hint: you can compare the two using ==
    # Replace the ____ below to implement the if statement.
    if ____:
        # TODO: Add a line below to print a success message to user.

        # TODO: Complete the print statement below to print the number
        # of steps the robot took. Remember, you can use "robot.num_motions"
        # to get the number of motions the robot executed.
        print(f'Number of steps: ...')
    else:
        # TODO: what would you print here, if the if condition was False?
        # If the if condition is True it means success, what would the 
        # False mean?


utils.check_input()
robot = utils.get_environment(sys.argv[1])
path = utils.path_finding(robot)

if path: # This checks if there was a valid path, nothing for you to do here.
    # TODO: call the function "move_robot_on_path" here to move 
    # the robot on the path. Don't forget to pass the arguments
    # "robot" and "path" (in this order). 
