import sys
from src import utils
from src.direction import Direction


def solve(robot):
    robot.move(Direction.Right)
    for i in range(6):
        robot.move(Direction.Down)
    for i in range(2):
        robot.move(Direction.Right)

    if robot.position == robot.goal_cell:
        print('Hooray the robot is at the goal position!!!')
        print(f'Number of steps: {robot.num_motions}')
    else:
        print('The robot failed to reach the goal :(')

utils.check_input()
robot = utils.get_environment(sys.argv[1])
solve(robot)
