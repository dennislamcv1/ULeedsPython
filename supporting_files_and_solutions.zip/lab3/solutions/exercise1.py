amount = float(input('What is the amount you want to borrow? '))
interest_rate_per_cent = 4
interest = amount * (interest_rate_per_cent / 100)
print(f'The interest you will pay in a year for Â£{amount} with an interest rate of {interest_rate_per_cent}% is Â£{interest}')

