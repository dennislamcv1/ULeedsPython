# TODO: Add a line below that will read the mark from the user
# using the input function. Remember to convert it to float using
# the function float(). Finally, remember to store this in a 
# variable: mark = ....


# TODO: Now create an if statement below that will check all
# the possibilities and print the classification accordingly.
# You will need to use the "if", "elif" and "else" we learnt.
# We provide an example for grade "A". This conditional 
# will check if the mark is between 8 and 10 (inclusive) and
# if so will print "A". Un-comment the lines below and 
# complete the code. To un-comment in Visual Studio Code 
# you can select the lines of interest and hit 
# "CTRL + /" on Windows or "CMD + /" on macOS (or simply
# remove the # and trailing white space from the lines below)

# if mark >= 8 and mark <= 10:
#     print('Student grade: A')
# elif TODO FOR YOU:
#     print('Student grade: B')
# elif TODO FOR YOU:
#     print('Student grade: C')
# elif TODO FOR YOU:
#     print('Student grade: F')
# else:
#     print('Wrong input: value must be between 1 and 10')
