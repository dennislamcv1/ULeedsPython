mark = float(input('Please provide the mark of the student: '))

if mark >= 8 and mark <= 10:
    print('Student grade: A')
elif mark >= 5 and mark <= 7:
    print('Student grade: B')
elif mark >= 4 and mark <= 6:
    print('Student grade: C')
elif mark >= 1 and mark <= 3:
    print('Student grade: F')
else:
    print('Wrong input: value must be between 1 and 10')
