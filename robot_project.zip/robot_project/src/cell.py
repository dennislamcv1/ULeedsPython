from dataclasses import dataclass

@dataclass
class Cell:
    row: int
    column: int

    def __str__(self):
        return f'({self.row}, {self.column})'

    def __hash__(self):
        return hash((self.row, self.column))

    def __lt__(self, other):
        return ((self.row - other.row) ** 2 + (self.column - other.column) ** 2) ** 0.5
