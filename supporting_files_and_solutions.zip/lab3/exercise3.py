# TODO: Add a line below that will read the first number from 
# the user. Don't forget to convert it to a float using float(). You
# need to store this in a variable. Something like this: 
# number_1 = ....


# TODO: Add a line below that will read the second number from 
# the user. Don't forget to convert it to a float using float(). You
# need to store this in a variable. Something like this: 
# number_2 = ....


# TODO: Finally, add **4 new lines** below that will use the print
# function to print the result of addition, subtraction,
# multiplication and division. For addition, something like
# this: print(f'Addition: {number_1 + number_2}')
# For addition use used "+" (see above). For subtraction use "-"", 
# for multiplication use "*", and for division use "/".
