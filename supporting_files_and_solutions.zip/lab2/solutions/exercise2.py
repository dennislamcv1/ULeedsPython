full_name = 'Your full name'
address_line = 'Your address line here'
post_code = 'Your post code here'
country = 'United Kingdom'
telephone_number = '+44 0000000000'

print(f'{full_name}\n{address_line}\n{post_code}\n{country}\n{telephone_number}')
