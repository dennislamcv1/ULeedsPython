total = 0

for i in range(1, 11):
    mark = float(input(f'Please provide the mark of student {i}: '))

    total += mark

    if mark >= 8 and mark <= 10:
        print(f'Student {i} grade: A')
    elif mark >= 5 and mark <= 7:
        print(f'Student {i} grade: B')
    elif mark >= 4 and mark <= 6:
        print(f'Student {i} grade: C')
    elif mark >= 1 and mark <= 3:
        print(f'Student {i} grade: F')

mean = total / 10
print(f'The mean of the class is {mean}')
