import random

def get_random_secret():
    return random.randint(0, 100)


def is_guess_valid(guess):
    return guess >= 0 and guess <= 100

def how_off_is_the_guess(guess, secret):
    diff = abs(guess - secret)
    if diff < 10:
        print('Very hot!')
    elif diff > 10 and diff <= 20:
        print('Hot')
    elif diff > 20 and diff <= 50:
        print('Cold')
    else:
        print('Very cold')

secret = get_random_secret()
counter = 1

while True:
    guess = int(input('Please provide a guess: '))

    if is_guess_valid(guess):
        if guess == secret:
            print(f'Congrats! The secret was {secret}. You found the secret after {counter} attempts.')
            break
        else:
            how_off_is_the_guess(guess, secret)

        counter += 1
    else:
        print('Please provide a number within the range [0, 100].')
