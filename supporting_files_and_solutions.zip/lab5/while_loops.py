# TODO: pick a secret number and set the secret variable below to whatever you like 
# (but an integer number between 0 and 100)!
secret = 

# TODO: initialise the counter variable to an initial value, what would that be? 
# If there was no guess yet, the counter will be ...
counter = 

while True:
    # TODO: read an input from user below and store it in the guess variable 
    # (remember to convert it to integer)
    guess = 

    counter = counter + 1

    #TODO: you need to write the conditional to check if given number is the 
    # secret (hint use == to compare for equality)
    if : 
        # TODO: the f-string needs to be completed, replace ___ with the required 
        # variables using {some_var}!
        print(f'Congrats! The secret number is ___ . You found the secret after ___ attempts.')

        # TODO: Here we want to stop the loop, which command did we learn that will "stop" a 
        # loop or BREAK out from a loop?
    else:
        # TODO: this is the else, what would you like to do if 
        # the guess is incorrect?

